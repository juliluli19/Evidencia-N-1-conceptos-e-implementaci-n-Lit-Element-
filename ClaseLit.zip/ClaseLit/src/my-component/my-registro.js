import { LitElement, html } from 'lit-element';
import stylesCss from './my-componentStyle.js';


export class MyRegistro extends LitElement {
  static get styles(){
    return[stylesCss]
}
  render() {
    return html`
    <form>
    <label>Nombres:</label>
    <br>
    <input type="text" id="" required>
    <br>
    <label>Apellidos:</label>
    <br>
    <input type="text" id="" required>
    <br>
    <label>Dirección:</label>
    <br>
    <input type="text" id="" required>
    <br>
    <label>Teléfono:</label>
    <br>
    <input type="number" id="" required>
    <br>
    <label>Correo:</label>
    <br>
    <input type="email" id="" required>
    <br>
    <label>Contraseña:</label>
    <br>
    <input type="password" id="" required>
    <br>
    <br>
    <input type="submit" name="enviar" class="enviar" value="Enviar">
</form>

    
    `;
  }
}

customElements.define('my-registro', MyRegistro);
