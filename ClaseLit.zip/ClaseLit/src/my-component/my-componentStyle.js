import { css } from "lit-element"

export default css`

form {
    background-color: #fff;
    border: 2px solid #4caf50;
    border-radius: 10px;
    text-align: center;
    width: 300px;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    margin-bottom: 5px;
    color: #4caf50;
}

input {
    width: 100%;
    border: 1px solid #4caf50;
    border-radius: 5px;
    height: 25px;
    margin-bottom: 10px;
    padding: 5px;
    box-sizing: border-box;
}

.enviar {
    background-color: #4caf50;
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px;
    cursor: pointer;
}

button {
    background-color: #2196f3;
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px;
    cursor: pointer;
    margin-top: 20px;
}

my-registro {
    background-color: #fff;
    border: 2px solid #2196f3;
    border-radius: 10px;
    padding: 20px;
    margin-top: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

`