import { LitElement, html } from 'lit-element';
import stylesCss from './my-componentStyle.js';


export class MyLogin extends LitElement {

static get styles(){
    return[stylesCss]
}
constructor() {
    super();
    this.showMyRegistro = false;
  }

  incrementar() {
    this.showMyRegistro = true;
  }

  render() {
    return html`
          <form>
              <label>Usuario:</label>
              <br>
              <input type="text" name="usu" id="" required>
              <br>
              <label>Contraseña:</label>
              <br>
              <input type="password" name="contra" id="" required>
              <br>
              <br>
              <input type="submit" name="enviar" class="enviar" value="Enviar">
              <br>
              <br>
          </form>
        <button @click="${this.incrementar}">Incrementar</button>
        ${this.showMyRegistro ? html`<my-registro></my-registro>` : ''}
    `;
  }
}

customElements.define('my-login', MyLogin);