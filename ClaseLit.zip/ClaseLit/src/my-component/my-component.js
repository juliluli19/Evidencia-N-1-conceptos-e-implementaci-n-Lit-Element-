import { LitElement, html } from 'lit-element';
import stylesCss from './my-componentStyle';

export class MyElement extends LitElement {


    static get scopedElements(){
        return {
            "my-inicio" : MyInitSesion,
            "my-registro": MyRegistro
        
        }
    }

    static get styles(){
        return [stylesCss]
    }

    constructor(){
        super()
        this.saludo = ""
        this.componentesHtml ="";
        this.paramComponent=0;
    }

    static get properties(){
        return{
            saludo: {type: String}
        }
    }

    cambio(){
        this.saludo = "Valentina Buenhombre"
    }

    renderAll(valor){
        if(this.paramComponent == 1){
            this.componentesHtml = html`<my-inicio></my-inicio>`
        }else{
            this.componentesHtml = html`<my-registro></my-registro>`
        }

    }

    mostrarComponente(){
        this.paramComponent = 2;
        this.renderAll();

    }

    mostrarLogin(){
        return html`<my-inicio></my-inicio>`
    }


    render() {

        this.paramComponent = 1;

        return html`
            ${this.componentesHtml}
            ${THIS.mostrarLogin()}
            <button @click="${(e) => this.mostrarComponente()}">Registrarse</button>
        
      `;
    }
  }
  
  customElements.define('my-element', MyElement);
